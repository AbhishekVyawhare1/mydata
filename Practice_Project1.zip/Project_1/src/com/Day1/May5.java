package com.Day1;

import java.util.Arrays;

//public class May5 {

//	public static void main(String[] args) {

////		Write a function to count the number of even and odd elements in an array.
////		Ex:
////		arr=[12,3,4,5,6,7,8,18]
////		odd numbers=3 [3,5,7]
////		even numbers=5   [12,4,6,8,18]
//		int[] arr = { 12, 3, 4, 5, 6, 7, 8, 18 };
//
//		int sum=0;
//		for(int a:arr) {
//			
//			if(arr[a]%2==0)
//				System.out.println(arr[a]);
//		}
//		
//	}
//	
//	
//	
////	public static void main(String[] args) {
////		int sum=0;
////		int n=15;
////		for(int i=0;i<=n;++i) {
////			sum +=i;
////		}
////		System.out.println(sum);
////	}
	
		public class May5 {
		    public static void countEvenOdd(int[] arr) {
		        int evenCount = 0;
		        int oddCount = 0;
		        int[] evenNumbers;
		        int[] oddNumbers;
		        
		        // Count the number of even and odd elements
		        for (int num : arr) {
		            if (num % 2 == 0) {
		                evenCount++;
		            } else {
		                oddCount++;
		            }
		        }
		        
		        // Create arrays to store the even and odd numbers
		        evenNumbers = new int[evenCount];
		        oddNumbers = new int[oddCount];
		        
		        // Populate the even and odd arrays
		        int evenIndex = 0;
		        int oddIndex = 0;
		        for (int num : arr) {
		            if (num % 2 == 0) {
		                evenNumbers[evenIndex] = num;
		                evenIndex++;
		            } else {
		                oddNumbers[oddIndex] = num;
		                oddIndex++;
		            }
		        }
		        
		        // Print the results
		        System.out.println("Odd numbers: " + oddCount + " " + Arrays.toString(oddNumbers));
		        System.out.println("Even numbers: " + evenCount + " " + Arrays.toString(evenNumbers));
		    }

			public stu() {
					super();
				}

		   

	}
	
}
