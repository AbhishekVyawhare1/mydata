
package com.Day1;

import java.util.List;
import java.util.*;

//
//public class Middle_Element {
//	public static void main(String[] args) {
//		String[] strings = { "Avneet", "Kaura" };
//
//		for (String s : strings) {
//			int length = s.length();
//
//			if (length % 2 == 0) { // 6%2=0
//				System.out.println(s + " Not Have Middle Charact");
//			} else {
//				int middleIndex = length / 2;
//				char middleChar = s.charAt(middleIndex);
//				System.out.println(s + " Middle Char is " + middleChar);
//			}
//		}
//	}
//
//}
//
public class Middle_Element
{
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the String: ");
		String str = input.nextLine();
		int pos;
		int len;
		if (str.length() % 2 == 0)
		{
			pos = str.length() / 2 - 1;
			len = 2;
		}
		else
		{
			pos = str.length() / 2;
			len = 1;
		}
		System.out.print("Middle character in the String : " + str.substring(pos, pos + len));
	}
}
//
//public class Middle_Element {
//
//	public static void main(String[] args) {
//		String[] s = { "Anu", "Anushka" };
//
//		for (String S1 : s) {
//
//			int a = S1.length();
//			if (a % 2 == 0) {
//				System.out.println(s + "not have middle char");
//			}else {
//				int middleIndex=a/2;      //3/2=1
//				char index=S1.charAt(middleIndex);
//				System.out.println(S1+" "+index);
//			}
//		}
//	}
//
//}
