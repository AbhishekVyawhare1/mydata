package com.Day1;

import java.util.Scanner;

public class New_Pattern {

	public static void main(String[] args) {

//		for (int i = 0; i < n; i++) {
//			char ch = 'A';
//			for (int j = 0; j < n - i; j++) {
//				System.out.print(ch++);
//			}
//			ch--;
//			for (int j = 0; j < 2 * i; j++) {
//				System.out.print(" ");
//			}
//			while (ch >= 'A') {
//				System.out.print(ch--);
//			}
//			System.out.println();
//		}
//	}
		Scanner S = new Scanner(System.in);
		int a = S.nextInt(); // Number of rows in the pattern
		int n = 11;
		for (int i = 0; i < n; i++) {
			char ch = 'A';
			for (int j = 0; j < n - i; j++) {
				System.out.print(ch++);
			}
			ch--;
			for (int j = 0; j < 2 * i; j++) {
				System.out.print(" ");
			}
			while (ch >= 'A') {
				System.out.print(ch--);
			}
			System.out.println();
		}
	}
}
//}
//
//
//nt n=11;
//for (int i = 0; i < n; i++) {
//	char ch = 'A';
//	for (int j = 0; j < n - i; j++) {
//		System.out.print(ch++);
//	}
//	ch--;
//	for (int j = 0; j < 2 * i; j++) {
//		System.out.print(" ");
//	}
//	while (ch >= 'A') {
//		System.out.print(ch--);
//	}
//	System.out.println();
//}