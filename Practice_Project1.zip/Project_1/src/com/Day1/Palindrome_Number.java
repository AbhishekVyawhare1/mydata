package com.Day1;

public class Palindrome_Number {

	public static void main(String[] args) {
		String name = "BAAB";
		String rev = "";
		for (int i = name.length() - 1; i >= 0; i--) {
			rev = rev + name.charAt(i);
		}
		if (rev.equals(name)) {
			System.out.println("Palindrome");
		} else {
			System.out.println("Not Palindrome");
		}
	}
}
