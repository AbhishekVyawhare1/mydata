package com.Day1;

public class PatternPyramid {

	public static void main(String[] args) {
		
	}
}
