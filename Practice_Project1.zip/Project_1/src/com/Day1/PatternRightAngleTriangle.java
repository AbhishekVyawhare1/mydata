package com.Day1;

import java.util.Scanner;

public class PatternRightAngleTriangle {

	public static void main(String[] args) {

		Scanner Im = new Scanner(System.in);
		System.out.println("Enter Value");
		int a = Im.nextInt();
		for (int i = 1; i <= a; i++) {

			for (int k = a-i; k >= i; k--) {
				System.out.print(" ");
			}
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

//	public static void main(String[] args) {
//		Scanner Im = new Scanner(System.in);
//		System.out.println("Enter Value");
//		int a = Im.nextInt();
//		for (int i = 1; i <= a; i++) {
//
//			for (int j = 1; j <= i; j++) {
//				System.out.print("*");
//			}
//			System.out.println();
//		}
//	}

//	public static void main(String[] args) {
//		for (int i = 1; i <= 4; i++) {
//			for (int j = 4; j >= i; j--) {
//				System.out.print("A");
//			}
//			System.out.println();
//		}
//	}

	// *
	// * *
	// * * *
	// * * * *
}
