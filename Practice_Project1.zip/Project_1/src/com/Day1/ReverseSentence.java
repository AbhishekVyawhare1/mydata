package com.Day1;

import java.util.Scanner;
import java.util.stream.Stream;

//

//public class ReverseSentence {
//
//	public static void main(String[] args) {
//		String S = "He is HI";
//
//		String r = " ";
//		for (int i = S.length() - 1; i >= 0; i--) {
//			r = r + S.charAt(i)+S.substring(3);
//		}
//		System.out.println(r);
//	}
//
//}
