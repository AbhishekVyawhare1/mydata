package com.exception;

public class UncheckedException {

	
	public static void main(String[] args) {
//		int a=1100;
//		System.out.println(a/0);//java.lang.ArithmeticException
		
//		String a1=null;
//		System.out.println(a1.length());//java.lang.NullPointerException
		
		
//		String sa="abcde";
//		int i=Integer.parseInt(sa);
//		System.out.println(i);//java.lang.NumberFormatException
		
		
		
//		int a[]=new int[10];
//		a[11]=550;
//		System.out.println(a);//java.lang.ArrayIndexOutOfBoundsException
	}
}
