package StreamMethods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

//distinct()
//limit()
//foreach()
//Max()
//Min()

public class Demo1 {

	

	/*
	 * public static void main(String[] args) { // List<String> list1 = new
	 * ArrayList<>(); // list1.add("Abhishek"); // list1.add("Gajanan"); //
	 * list1.add("Vyawhare"); // list1.add("Avneet"); // list1.add("Patel"); // //
	 * List<String> name = list1.stream().distinct().collect(Collectors.toList());
	 * // System.out.println(name); // // list1.stream().limit(3).forEach(a ->
	 * System.out.println(a)); // // long count = list1.stream().count(); //
	 * System.out.println(count);
	 * 
	 * 
	 * List<Integer>list2=Arrays.asList(1,2,3,4,2,4); // long
	 * f=list2.stream().filter(t->t%2==0).count(); // System.out.println(f);
	 * 
	 * 
	 * // Optional<Integer>max=list2.stream().max((a11,a2)->{ // return
	 * a11.compareTo(a2); // }); // System.out.println(max.get());
	 * 
	 * 
	 * }
	 */
}
