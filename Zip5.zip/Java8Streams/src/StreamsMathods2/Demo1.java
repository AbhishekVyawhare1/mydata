package StreamsMathods2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

//sorted
public class Demo1 {

//	public static void main(String[] args) {
//		List<Integer> list1 = Arrays.asList(9, 4, 1, 3, 2, 5, 7, 8);
//		List<Integer> sortedlist = list1.stream().sorted().collect(Collectors.toList());
//
//		System.out.println(sortedlist);// ascending order
//
//		List<Integer> reverseorderlist = list1.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
//
//		System.out.println(sortedlist);// descending order
//
//		//Strings
//		List<String> list2=Arrays.asList("Abhi","mary","kim","Avneet","abhi","AvNEET");
//		list2.stream().sorted().forEach(a->System.out.println(a));
//	}
	
	
}
