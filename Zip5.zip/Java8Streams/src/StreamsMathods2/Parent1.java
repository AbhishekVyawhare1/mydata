package StreamsMathods2;

public class Parent1 {

	
	int a=10;
	int b=20;
	void m1() {
		System.out.println("In Parent");
	}
}
