package filterdemos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class FilterDemo2 {

//	public static void main(String[] args) {
//
//		List<String> name = Arrays.asList("Melisandra", "Sansa", "soon", "aaeneyras", "Joffery");
//
//		List<String> longnames = new ArrayList<>();
//
////		longnames=name.stream().filter(str->str.length()>6 && str.length()<8).collect(Collectors.toList());
////		System.out.println(longnames);
//
//		name.stream().filter(str -> str.length() > 6 && str.length() < 8).forEach(n -> System.out.println(n));
//
//		name.stream().filter(str -> str.length() > 6 && str.length() < 8).forEach(System.out::println);
//
//	}

//	public static void main(String[] args) {
//
//		Scanner s = new Scanner(System.in);
//		System.out.println("Enter number");
//		int a = s.nextInt();
//		System.out.println("Enter Names");
//		List<String> names = new ArrayList<>();
//
//		for (int i = 0; i <= a; i++) {
//			names.add(s.next());
//		}
//
//		names.stream().filter(av -> av.length() > 6 && av.length() < 8).forEach(System.out::println);
//	}

	
}
