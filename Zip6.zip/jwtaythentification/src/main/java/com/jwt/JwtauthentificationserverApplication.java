package com.jwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtauthentificationserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtauthentificationserverApplication.class, args);
	}

}
