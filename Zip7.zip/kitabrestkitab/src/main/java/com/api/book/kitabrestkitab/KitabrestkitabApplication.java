package com.api.book.kitabrestkitab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KitabrestkitabApplication {

	public static void main(String[] args) {
		SpringApplication.run(KitabrestkitabApplication.class, args);
	}

}
