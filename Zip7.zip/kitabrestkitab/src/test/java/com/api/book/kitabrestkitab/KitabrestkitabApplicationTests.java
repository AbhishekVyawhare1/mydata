package com.api.book.kitabrestkitab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KitabrestkitabApplicationTests {

	@Test
	void contextLoads() {
	}

}
