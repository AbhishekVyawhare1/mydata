package Functions;

import java.util.function.Function;

public class Demo1 {

	public static void main(String[] args) {
	
		
//		Function<Integer, Integer>f1=f->f*f;
//		System.out.println(f1.apply(5));
//		System.out.println(f1.apply(10));
//		System.out.println(f1.apply(52560));
//		
//		Function<String, Integer>a1=a->a.length();
//		System.out.println(a1.apply("Abhishek"));
//		System.out.println(a1.apply("Gajanan"));
//		System.out.println(a1.apply("Vyawhare"));
		
	
	}
}
